# Turtel-And-a-Pakour

A 2D parkour game made with Unity. The original game is playable in a web browser here:

https://odindc-crypto.github.io/Turtel-And-a-Pakour/

## Controls

- Move: A/D or Left/Right Arrow
- Jump: Space or W
- Dash: Shift
- Climb: hold W near a wall
